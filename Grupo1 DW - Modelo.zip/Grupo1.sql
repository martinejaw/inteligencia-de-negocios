/*
 * ER/Studio 8.0 SQL Code Generation
 * Company :      Matrix
 * Project :      LogicModelv4.DM1
 * Author :       JT
 *
 * Date Created : Wednesday, June 16, 2021 11:14:51
 * Target DBMS : Microsoft SQL Server 2008
 */

/* 
 * TABLE: DimAccount 
 */

CREATE TABLE DimAccount(
    id_account    int    NOT NULL,
    CONSTRAINT PK3 PRIMARY KEY NONCLUSTERED (id_account)
)
go



IF OBJECT_ID('DimAccount') IS NOT NULL
    PRINT '<<< CREATED TABLE DimAccount >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimAccount >>>'
go

/* 
 * TABLE: DimClient 
 */

CREATE TABLE DimClient(
    id_client      int            NOT NULL,
    fromDate       date           NOT NULL,
    toDate         date           NULL,
    sex            varchar(50)    NOT NULL,
    id_district    int            NOT NULL,
    birthday       date           NOT NULL,
    CONSTRAINT PK6 PRIMARY KEY NONCLUSTERED (id_client, fromDate)
)
go



IF OBJECT_ID('DimClient') IS NOT NULL
    PRINT '<<< CREATED TABLE DimClient >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimClient >>>'
go

/* 
 * TABLE: DimDate 
 */

CREATE TABLE DimDate(
    date_key          date           NOT NULL,
    monthNumber       char(10)       NULL,
    nameMonth         char(10)       NULL,
    quarterNumber     int            NOT NULL,
    semesterNumber    int            NOT NULL,
    yearNumber        int            NOT NULL,
    dayNumberWeek     int            NOT NULL,
    dayNumberMonth    int            NOT NULL,
    dayNumberYear     int            NOT NULL,
    isWeekend         bit            NOT NULL,
    dayName           varchar(50)    NOT NULL,
    CONSTRAINT PK4 PRIMARY KEY NONCLUSTERED (date_key)
)
go



IF OBJECT_ID('DimDate') IS NOT NULL
    PRINT '<<< CREATED TABLE DimDate >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimDate >>>'
go

/* 
 * TABLE: DimDistrict 
 */

CREATE TABLE DimDistrict(
    id_district                    int            NOT NULL,
    no_habitants                   int            NOT NULL,
    nameDistrict                   varchar(50)    NULL,
    [no_municipalities500-1999]    int            NULL,
    [no_municipalities2000-9999]   int            NULL,
    no_municipalities_more10000    int            NULL,
    ratioUrbanHabitants            float          NULL,
    avgSalary                      float          NULL,
    rateUnemployment95             float          NULL,
    rateUnemployment96             float          NULL,
    no_enterpreneurs_1000          int            NULL,
    no_crime95                     int            NULL,
    no_crime96                     int            NULL,
    [clients0-19Age]               int            DEFAULT 0 NULL,
    [clients20-29Age]              int            NULL,
    [clients30-39Age]              int            NULL,
    [clients40-49Age]              int            NULL,
    clientsMore50Age               int            NULL,
    clientsMale                    int            NULL,
    clientsFemale                  int            NULL,
    no_cities                      int            NOT NULL,
    no_municipalities_less499      int            NULL,
    nameRegion                     varchar(50)    NOT NULL,
    CONSTRAINT PK2 PRIMARY KEY NONCLUSTERED (id_district)
)
go



IF OBJECT_ID('DimDistrict') IS NOT NULL
    PRINT '<<< CREATED TABLE DimDistrict >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimDistrict >>>'
go

/* 
 * TABLE: DimKTypeOrder 
 */

CREATE TABLE DimKTypeOrder(
    ktype_order    varchar(50)    NOT NULL,
    CONSTRAINT PK23 PRIMARY KEY NONCLUSTERED (ktype_order)
)
go



IF OBJECT_ID('DimKTypeOrder') IS NOT NULL
    PRINT '<<< CREATED TABLE DimKTypeOrder >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimKTypeOrder >>>'
go

/* 
 * TABLE: DimKTypeTransaction 
 */

CREATE TABLE DimKTypeTransaction(
    ktype_transaction    varchar(50)    NOT NULL,
    CONSTRAINT PK21 PRIMARY KEY NONCLUSTERED (ktype_transaction)
)
go



IF OBJECT_ID('DimKTypeTransaction') IS NOT NULL
    PRINT '<<< CREATED TABLE DimKTypeTransaction >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimKTypeTransaction >>>'
go

/* 
 * TABLE: DimOperation 
 */

CREATE TABLE DimOperation(
    operation    varchar(50)    NOT NULL,
    CONSTRAINT PK20 PRIMARY KEY NONCLUSTERED (operation)
)
go



IF OBJECT_ID('DimOperation') IS NOT NULL
    PRINT '<<< CREATED TABLE DimOperation >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimOperation >>>'
go

/* 
 * TABLE: DimRegion 
 */

CREATE TABLE DimRegion(
    nameRegion           varchar(50)    NOT NULL,
    quantityDistricts    int            NULL,
    CONSTRAINT PK8 PRIMARY KEY NONCLUSTERED (nameRegion)
)
go



IF OBJECT_ID('DimRegion') IS NOT NULL
    PRINT '<<< CREATED TABLE DimRegion >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimRegion >>>'
go

/* 
 * TABLE: DimStatus 
 */

CREATE TABLE DimStatus(
    status    varchar(50)    NOT NULL,
    CONSTRAINT PK19 PRIMARY KEY NONCLUSTERED (status)
)
go



IF OBJECT_ID('DimStatus') IS NOT NULL
    PRINT '<<< CREATED TABLE DimStatus >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimStatus >>>'
go

/* 
 * TABLE: DimType 
 */

CREATE TABLE DimType(
    type    varchar(50)    NOT NULL,
    CONSTRAINT PK14 PRIMARY KEY NONCLUSTERED (type)
)
go



IF OBJECT_ID('DimType') IS NOT NULL
    PRINT '<<< CREATED TABLE DimType >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE DimType >>>'
go

/* 
 * TABLE: FactDisposition 
 */

CREATE TABLE FactDisposition(
    id_account       int     NOT NULL,
    id_client        int     NOT NULL,
    fromDate         date    NOT NULL,
    isOwner          bit     NOT NULL,
    hasCreditCard    bit     NOT NULL
)
go



IF OBJECT_ID('FactDisposition') IS NOT NULL
    PRINT '<<< CREATED TABLE FactDisposition >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE FactDisposition >>>'
go

/* 
 * TABLE: FactLoan 
 */

CREATE TABLE FactLoan(
    amount         decimal(18, 2)    NOT NULL,
    quantity       int               NOT NULL,
    status         varchar(50)       NOT NULL,
    date_key       date              NOT NULL,
    id_district    int               NOT NULL,
    id_account     int               NOT NULL
)
go



IF OBJECT_ID('FactLoan') IS NOT NULL
    PRINT '<<< CREATED TABLE FactLoan >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE FactLoan >>>'
go

/* 
 * TABLE: FactPermanentOrder 
 */

CREATE TABLE FactPermanentOrder(
    amount         decimal(18, 2)    NOT NULL,
    quantity       int               NOT NULL,
    id_district    int               NOT NULL,
    id_account     int               NOT NULL,
    ktype_order    varchar(50)       NOT NULL
)
go



IF OBJECT_ID('FactPermanentOrder') IS NOT NULL
    PRINT '<<< CREATED TABLE FactPermanentOrder >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE FactPermanentOrder >>>'
go

/* 
 * TABLE: FactTransaction 
 */

CREATE TABLE FactTransaction(
    id_account           int               NOT NULL,
    date_key             date              NOT NULL,
    type                 varchar(50)       NOT NULL,
    amount               decimal(18, 2)    NULL,
    quantity             int               NULL,
    id_district          int               NOT NULL,
    operation            varchar(50)       NOT NULL,
    ktype_transaction    varchar(50)       NOT NULL
)
go



IF OBJECT_ID('FactTransaction') IS NOT NULL
    PRINT '<<< CREATED TABLE FactTransaction >>>'
ELSE
    PRINT '<<< FAILED CREATING TABLE FactTransaction >>>'
go

/* 
 * TABLE: DimClient 
 */

ALTER TABLE DimClient ADD CONSTRAINT RefDimDistrict44 
    FOREIGN KEY (id_district)
    REFERENCES DimDistrict(id_district)
go

ALTER TABLE DimClient ADD CONSTRAINT RefDimDate45 
    FOREIGN KEY (birthday)
    REFERENCES DimDate(date_key)
go


/* 
 * TABLE: DimDistrict 
 */

ALTER TABLE DimDistrict ADD CONSTRAINT RefDimRegion31 
    FOREIGN KEY (nameRegion)
    REFERENCES DimRegion(nameRegion)
go


/* 
 * TABLE: FactDisposition 
 */

ALTER TABLE FactDisposition ADD CONSTRAINT RefDimClient18 
    FOREIGN KEY (id_client, fromDate)
    REFERENCES DimClient(id_client, fromDate)
go

ALTER TABLE FactDisposition ADD CONSTRAINT RefDimAccount27 
    FOREIGN KEY (id_account)
    REFERENCES DimAccount(id_account)
go


/* 
 * TABLE: FactLoan 
 */

ALTER TABLE FactLoan ADD CONSTRAINT RefDimStatus32 
    FOREIGN KEY (status)
    REFERENCES DimStatus(status)
go

ALTER TABLE FactLoan ADD CONSTRAINT RefDimDate33 
    FOREIGN KEY (date_key)
    REFERENCES DimDate(date_key)
go

ALTER TABLE FactLoan ADD CONSTRAINT RefDimDistrict34 
    FOREIGN KEY (id_district)
    REFERENCES DimDistrict(id_district)
go

ALTER TABLE FactLoan ADD CONSTRAINT RefDimAccount35 
    FOREIGN KEY (id_account)
    REFERENCES DimAccount(id_account)
go


/* 
 * TABLE: FactPermanentOrder 
 */

ALTER TABLE FactPermanentOrder ADD CONSTRAINT RefDimDistrict40 
    FOREIGN KEY (id_district)
    REFERENCES DimDistrict(id_district)
go

ALTER TABLE FactPermanentOrder ADD CONSTRAINT RefDimAccount41 
    FOREIGN KEY (id_account)
    REFERENCES DimAccount(id_account)
go

ALTER TABLE FactPermanentOrder ADD CONSTRAINT RefDimKTypeOrder42 
    FOREIGN KEY (ktype_order)
    REFERENCES DimKTypeOrder(ktype_order)
go


/* 
 * TABLE: FactTransaction 
 */

ALTER TABLE FactTransaction ADD CONSTRAINT RefDimType23 
    FOREIGN KEY (type)
    REFERENCES DimType(type)
go

ALTER TABLE FactTransaction ADD CONSTRAINT RefDimDate24 
    FOREIGN KEY (date_key)
    REFERENCES DimDate(date_key)
go

ALTER TABLE FactTransaction ADD CONSTRAINT RefDimAccount25 
    FOREIGN KEY (id_account)
    REFERENCES DimAccount(id_account)
go

ALTER TABLE FactTransaction ADD CONSTRAINT RefDimDistrict30 
    FOREIGN KEY (id_district)
    REFERENCES DimDistrict(id_district)
go

ALTER TABLE FactTransaction ADD CONSTRAINT RefDimOperation37 
    FOREIGN KEY (operation)
    REFERENCES DimOperation(operation)
go

ALTER TABLE FactTransaction ADD CONSTRAINT RefDimKTypeTransaction39 
    FOREIGN KEY (ktype_transaction)
    REFERENCES DimKTypeTransaction(ktype_transaction)
go


